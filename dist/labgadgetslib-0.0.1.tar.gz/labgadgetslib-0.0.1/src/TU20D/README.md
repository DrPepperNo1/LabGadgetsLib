# TU20D SOFTWARE MANUAL
## Dependent Python Packages
1. pyqt5
2. pyqt5-tools
3. pyserial
## How to Run
1. Install RS232 Drive: https://download2261.mediafire.com/jhcwmy0358pg/k5mkp4azlygnyad/PL2303GT%283%29.rar
2. Connect your laptop to TU20D via RS232 to USB cable
3. Just Run the GUI.py
